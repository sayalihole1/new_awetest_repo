# These are the 'step definitions' which Cucumber uses to implement features.
#
# Each step starts with a regular expression matching the step you write in
# your feature description.  Any variables are parsed out and passed to the
# step block.
#
# The instructions in the step are then executed with those variables.
#
# In this example, we're using rspec's assertions to test that things are happening,
# but you can use any ruby code you want in the steps.
#
# The '$driver' object is the appium_lib driver, set up in the cucumber/support/env.rb
# file, which is a convenient place to put it as we're likely to use it often.
# This is a different use to most of the examples;  Cucumber steps are instances
# of `Object`, and extending Object with Appium methods (through 
# `promote_appium_methods`) is a bad idea.
#
# For more on step definitions, check out the documentation at
# https://github.com/cucumber/cucumber/wiki/Step-Definitions
#
# For more on rspec assertions, check out
# https://www.relishapp.com/rspec/rspec-expectations/docs

Given /^I have entered (\d+) into field 1 of the calculator$/ do |value|
  # Get a textfield by index
  el = $driver.find_element(xpath: "//UIAApplication[1]/UIAWindow[2]/UIATextField[1]")
  el.type(value)
end

Given /^I have entered (\d+) into field 2 of the calculator$/ do |value|
  # Get a textfield by index
  el = $driver.find_element(xpath: "//UIAApplication[1]/UIAWindow[2]/UIATextField[2]")
  el.type(value)
end



And /^I press button Add$/ do 
  # Find a button by index
  el = $driver.find_element(xpath: "//UIAApplication[1]/UIAWindow[2]/UIAButton[1]")
  el.click
end


Then /^the result should be displayed as (\d+)$/ do |expected|
  # You can get just the first of a class of elements
  el = $driver.find_element(xpath: "//UIAApplication[1]/UIAWindow[2]/UIAStaticText[3]")
  el.value.should eq expected
end