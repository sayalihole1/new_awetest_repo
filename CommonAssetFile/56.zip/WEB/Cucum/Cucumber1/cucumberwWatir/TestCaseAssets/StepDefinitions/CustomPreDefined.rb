Then(/^I enter this text "(.*?)" in the search box$/) do |arg1|
  @browser.text_field(:id,'gbqfq').set("#{arg1}")
end

Then(/^I go to the given url "(.*?)"$/) do |arg1|
  @browser.goto("#{arg1}") 
end