require 'watir'
browser = Watir::Browser.new
browser.goto 'watir.com'
browser.link(text: 'documentadtion').click
##browser.text.include? "gaqrbvafengfduhye"
browser.close