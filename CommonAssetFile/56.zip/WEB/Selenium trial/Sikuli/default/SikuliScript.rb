module ShortPassingSikuliTest

  def run
    browser = open_browser
    go_to_url(browser, 'http://localhost:4567/form.html')
    run_sikuli_script('embedded_test')
    logout(browser)
  end

end
