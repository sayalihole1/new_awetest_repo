Then /^I fill in with value "(.*?)"$/ do |value|   
  @browser.text_field(:name, "q").set value
end
Then /^I click the search button "(.*?)"$/ do |element_text|
	sleep 1
  @browser.button(:name, element_text).click
end

Given /^I connect to the webdriver browser$/ do
	require 'watir-webdriver'
	@browser = Watir::Browser.new(:remote, :url=>'http://192.168.1.107:3001/wd/hub/')
	#browser = Watir::Browser.new(:remote, :url=>'http://localhost:8080/wd/hub/')
end

Then /^I wait (\d+) seconds?$/ do |seconds|
  sleep seconds.to_i
end

Then /^I go to the url "(.*?)"$/ do |url|
  @browser.goto url
end

def navigate_to_environment_url
  if @params and @params['environment'] and @params['environment']['url']
  url = @params['environment']['url']
  elsif @login and @login['url']
    url = @login['url']
  elsif @role and @login[@role] and @login[@role]['url']
    url = @login[@role]['url']
  end
  @browser.goto url
end

Then /^I should see "(.*?)"$/ do |text|
  stm = false
  begin
  @wait.until {stm = @browser.text.include? text
  stm }
  rescue => e
  end
  fail("Did not find text #{text} \n #{e.message}") unless stm
  stm
end