Then /^I test three elements$/ do
	touch("view marked:'Actinium'")
	sleep 3
	touch("view marked:'Back'")
	sleep 3
	touch("view marked:'Aluminum'")
	sleep 3
	touch("view marked:'Back'")
	sleep 3
	touch("view marked:'Americium'")
	sleep 3
	touch("view marked:'Back'")
	sleep 3
end