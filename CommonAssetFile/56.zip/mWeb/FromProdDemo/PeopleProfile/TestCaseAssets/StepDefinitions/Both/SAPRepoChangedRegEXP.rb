#Then(/^I click "([^"]*)" button$/) do |arg1|
#obj_info=@obj_repo_row["#{arg1}"]
 # @browser.button(obj_info[0].to_sym, "#{obj_info[1].to_s}").click
  #sleep 3
 # expect(@params['variables']['Variable Group 1']['foo']).to eq('bar')
#end
require 'pry'
Then(/^click "([^"]*)"$/) do |arg1|

	el = find_el(arg1)
	el.when_present.flash
	wait_until_ready(el)
	el.click
	sleep 1
end

Then(/^click "([^"]*)" from homepage$/) do |arg1|

  el = find_el(arg1)
  el.when_present.flash
  wait_until_ready(el)
  el.click
  sleep(10)
  if el.visible?
    el.click
  else
    puts "click worked"
  end
  sleep 1
end

Then(/^click "([^"]*)" to select list$/) do |arg1|

  el = find_el(arg1)
  el.when_present.flash
  wait_until_ready(el)
  el.click
  sleep(10)
  until @browser.li(:class => "sapMSelectListItem").visible? do
    el.click
  end
  sleep 1
end

Then(/^click "([^"]*)" to select list for interval$/) do |arg1|

  el = find_el(arg1)
  el.when_present.flash
  wait_until_ready(el)
  el.click
  sleep(10)
  until @browser.li(:text => "Weekly").visible? do
    el.click
  end
  sleep 1
end

Then(/^click "([^"]*)" if present$/) do |arg1|

  el = find_el(arg1)
  begin
  Watir::Wait.until(15){el.flash}
  wait_until_ready(el)
  el.click
  sleep 1
  rescue

  end
end


def wait_until_ready(el)
 Watir::Wait.until {el.exists? && el.visible? && el.enabled?} rescue nil
 el
end

Then(/^I hover over "([^"]*)"$/) do |arg1|
    el = find_el(arg1)
	el.when_present.flash
	el.hover
end

def find_el(el_name, visible=true)
	obj_info=@obj_repo_row["#{el_name}"]
	parent = @browser
	target= nil
	if obj_info[4]
		target = find_els(el_name)[obj_info[4].to_i]
	else
		
		if obj_info[3] 
			frame =@obj_repo_row["#{obj_info[3]}"]
			if frame[2] == 'iframe'
				parent =  @browser.iframe(frame[0].to_sym, "#{frame[1]}")
			elsif  frame[2] == 'form'
				parent = @browser.form(frame[0].to_sym, "#{frame[1]}")	
			end
		end
			
		if (obj_info[2] == "link")
			target = parent.link(obj_info[0].to_sym, "#{obj_info[1]}")
		elsif (obj_info[2] == "button")
			target = parent.button(obj_info[0].to_sym, "#{obj_info[1]}")
		elsif (obj_info[2] == "name")
			target = parent.name(obj_info[0].to_sym, "#{obj_info[1]}")
		elsif (obj_info[2] == "title")
			target = parent.title(obj_info[0].to_sym, /#{obj_info[1]}/)
		elsif (obj_info[2] == "image")
			target = parent.image(obj_info[0].to_sym, "#{obj_info[1]}")
    elsif (obj_info[2] == "label")
      target = parent.label(obj_info[0].to_sym, "#{obj_info[1]}")
		elsif (obj_info[2] == "span")
			target = parent.span(obj_info[0].to_sym, "#{obj_info[1]}")
		elsif (obj_info[2] == "text_field")
		target = parent.text_field(obj_info[0].to_sym, "#{obj_info[1]}")
		else
			target = parent.element(obj_info[0].to_sym, /#{obj_info[1]}/)
		end
	end
	
	#sometimes when_present does not work for textfiels that are not visible. 
	#this is a workaround for that
	if  not (obj_info[2] == "text_field")
	el_visible =  target.when_present.visible? rescue false
	else
	@browser.driver.manage.timeouts.implicit_wait= 1
	 target.when_present rescue nil
	 el_visible = target.visible?
	 @browser.driver.manage.timeouts.implicit_wait= 30
	end
	if visible && !el_visible
		els = find_els(el_name)
		els.each do |el|
			if el.visible?
				target = el 
				break 
			end
		end	
	end
	target
end



def find_els(el_name)
	obj_info=@obj_repo_row["#{el_name}"]
	parent = @browser
	target= []
	if obj_info[3] 
		frame =@obj_repo_row["#{obj_info[3]}"]
		if frame[2] == 'iframe'
			parent =  @browser.iframe(frame[0].to_sym, "#{frame[1]}")
		elsif  frame[2] == 'form'
			parent = @browser.form(frame[0].to_sym, "#{frame[1]}")	
		end
	end
			
		if (obj_info[2] == "link")
			target = parent.links(obj_info[0].to_sym, "#{obj_info[1]}")
		elsif (obj_info[2] == "button")
			target = parent.buttons(obj_info[0].to_sym, "#{obj_info[1]}")
		elsif (obj_info[2] == "name")
			target = parent.names(obj_info[0].to_sym, "#{obj_info[1]}")
		elsif (obj_info[2] == "image")
			target = parent.images(obj_info[0].to_sym, "#{obj_info[1]}")
		elsif (obj_info[2] == "span")
			target = parent.spans(obj_info[0].to_sym, "#{obj_info[1]}")
		elsif (obj_info[2] == "text_field")
		target = parent.text_fields(obj_info[0].to_sym, "#{obj_info[1]}")
		else
			target = parent.elements(obj_info[0].to_sym, "#{obj_info[1]}")
		end

		target
end


Then(/^I select "([^"]*)" from "([^"]*)"$/) do |arg1, arg2|
  obj_info=@obj_repo_row["#{arg2}"]
  user_data=@user_data_row["#{arg1}"]
  
    @browser.select_list(obj_info[0].to_sym, "#{obj_info[1]}").when_present.select_value("#{user_data}")
end 

def get_user_data(key)
	key = @user_data_row["#{key}"]  if  @user_data_row["#{key}"] 
	key
end

Then(/^I enter "([^"]*)" in "([^"]*)"$/) do |text_to_enter, text_field_name|
 el = find_el(text_field_name)
 user_data= get_user_data(text_to_enter)
 el.when_present.flash
	 begin
		el.set("#{user_data}")
   rescue
    el.send_keys [:control, 'a'], :backspace
		el.send_keys("#{user_data}")
	 end
end


Then(/^I should see element "([^"]*)"$/) do |arg1|
  el = find_el(arg1)

	raise("#{arg1} is missing") unless el.visible?
	el.flash

end

Then(/^I read the data from the spreadsheet$/) do
	require 'spreadsheet'
	Spreadsheet.client_encoding = 'UTF-8'
	@myRoot = File.join(File.dirname(__FILE__),'/')
	book = Spreadsheet.open "#{@myRoot}SAPFioriRepo.xls"
	# book = Spreadsheet.open 'excel-file.xls'
	book.worksheets
	obj_repo = book.worksheet 'obj_repo'
	user_data = book.worksheet 'user_data'
	login = book.worksheet 'login'
	
	@login_row = {}
	login.each do |row|
		row.each do |x| 
			@login_row[row[0]] = row[1..3]
		end
	end
	@obj_repo_row = {}
	obj_repo.each do |row|
		row.each do |x| 
			@obj_repo_row[row[0]] = row[1..4]
		end
	end
	@user_data_row = {}
	user_data.each do |row|
		row.each do |x| 
			@user_data_row[row[0]] = row[1]
		end
	end
end