#setFindFailedResponse(PROMPT)
App.open("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe")
type("WMozillaFire.png", "https://accounts.zoho.com/login?serviceurl=https://www.zoho.com/&hide_signup=true&css=https://www.zoho.com/css/login.css"+ Key.ENTER)
wait(5)
type("Username.png", 'joeklienwatir@gmail.com'+ Key.TAB)
type("Password.png", 'watir001')            
click("SignIn.png");wait(2)
wheel(WHEEL_DOWN, 23);wait(3)
click("CRfScfmrare.png");wait(5)
click("1362607897729.png");wait(3)
click("hhzwAccount.png");wait(3)
type("Accc1untNamn.png", 'testzoho');wait(1)
click("1362615911647.png");wait(3)
if exists("AccountNamet.png"):
    print "Account creation verified"
click("Delete-1.png");wait(2)
click("OK-1.png");wait(2)
Region(6,150,1251,613).exists("testzoho")
click("1362680108146.png");wait(1)
click("1362680128821.png");wait(3)
click("1362680173591.png")
    
    


   
   
   













