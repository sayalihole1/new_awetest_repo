App.open("C:\\Program Files\\Mozilla Firefox\\firefox.exe")
wait(2)
type("G0t0aWebsite.png", "https://accounts.zoho.com/login?serviceurl=https://www.zoho.com/&hide_signup=true&css=https://www.zoho.com/css/login.css"+ Key.ENTER)
wait(5)
type("Username.png", 'joeklienwatir@gmail.com'+ Key.TAB)
type("Password.png", 'watir001');wait(1)     
click("Signln.png");wait(4)
wheel(WHEEL_DOWN, 85);wait(4)
click("CRfScfmrare.png");wait(5)
click("1362607897729.png");wait(4)
click("hhzwAccount.png");wait(3)
type("Accc1untNamn.png", 'testzoho');wait(1)
click("1362615911647.png");wait(3)
if exists("AccountNamet.png"):
    print "Account creation verified"
click("Delete-1.png");wait(2)
click("OK.png");wait(2)
Region(11,164,1233,573).exists("testzoho")
click("l.png");wait(1)
click("1362680128821.png");wait(3)
click("1362680173591.png")
    
    


   
   
   













