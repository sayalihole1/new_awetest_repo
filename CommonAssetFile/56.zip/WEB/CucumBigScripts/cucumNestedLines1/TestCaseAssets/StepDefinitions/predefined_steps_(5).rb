Then /^I execute nested steps$/ do   
 	step "I open a new browser"
	step "I go to the url \"facebook.com\""
  
end

# Then(/^I wait (\d+) seconds?$/)do |seconds|
#   sleep seconds.to_i
# end
