$:.unshift File.join(File.dirname(__FILE__))
$:.unshift File.join(File.dirname(__FILE__), 'bin')
$:.unshift File.join(File.dirname(__FILE__), 'lib')
require 'active_support'
require 'active_support/inflector'
require 'active_support/core_ext/object'
require 'active_support/core_ext/hash'
require 'rest-client'
require 'yaml'

hostnames = 5.times.collect{|i| "ShamisenTest#{i}"}

CONFIG_YML = File.join File.dirname(__FILE__), 'config', 'settings.yml'
CONFIG = YAML::load_file(CONFIG_YML).with_indifferent_access

base_url = "http://localhost:3000/api/v1"

hostnames.each do |hostname|
  config = CONFIG.merge(:worker_id => "#{CONFIG[:shamisen_name]}_#{hostname}",:shamisen_name => "#{CONFIG[:shamisen_name]}_#{hostname}",:private_shamisen_user => nil)
  RestClient.post "#{base_url}/shamisen_workers/update_or_create", {:hostname => Base64.encode64(hostname), :config => config.to_json}
end

hostnames.each do |hostname|
  RestClient.post "#{base_url}/workers/notify_awetest",{:params => {:class => 'Shamisen::WorkerPresenceNotifier',:queue => 'notifications',:hostname => Base64.encode64(hostname)}}
  sleep 1
end

# while true
#   hostnames.each do |hostname|
#     RestClient.post "#{base_url}/workers/notify_awetest",{:params => {:class => 'Shamisen::WorkerPresenceNotifier',:queue => 'notifications',:hostname => Base64.encode64(hostname)}}
#     sleep 1
#   end
# end
