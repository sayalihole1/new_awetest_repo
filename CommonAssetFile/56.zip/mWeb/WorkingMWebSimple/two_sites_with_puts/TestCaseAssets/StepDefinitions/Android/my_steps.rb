# def sample_line
#   sleep 5
#   puts 'Sample puts test'
# end

Then /^I go to sample line$/ do
#  @browser.goto("https://accounts.zoho.com/login?serviceurl=https://www.zoho.com/&hide_signup=true&css=https://www.zoho.com/css/login.css")
  sleep 5
  puts 'Sample puts test' 
end