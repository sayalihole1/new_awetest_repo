Then /^I go to awetest$/ do
  @browser.goto "http://localhost:3000"
end


Given /^I am on a login page$/ do
  unless username_element && password_element && login_element
    fail("Not on a login page")
  end
end

When /^I fill in username and password with "([^"]*)" and "([^"]*)" respectively$/ do |username, password|
  username_element.set(username)
  password_element.set(password)
end

Then /^The values in username and password should be "([^"]*)" and "([^"]*)" respectively$/ do |username, password|
  unless (username_element.value == username) && (password_element.value == password)
    fail("Values are not as per expectations")
  end
end

And /^I click on Sign In$/ do
  login_element.wait_until_present.click
end

Then /^I should see the text "(.*?)"$/ do |message|
  sleep 6
  message_text = @variable_group[message] ?  @variable_group[message] : fail("Please define #{message.humanize} value in test variable with key #{message}" )

  unless @browser.text.include?(message_text)
    fail("Did not find #{message_text} on the page")
  end
end

When /^I am on dashboard$/ do
  unless @browser.text.include?('Dashboard')
    fail("Not on dashboard page")
  end
end

Then /^I go to web test case page$/ do
  sleep 6
  @browser.link(:href,"/web/dashboard").hover
  sleep 3
  target = @browser.link(:href, "/web/test_cases")
  target.when_present.click
end

Then /^I go to mweb test case page$/ do
  sleep 6
  if(mweb_dashboard_link.present?)
    mweb_dashboard_link.hover
    sleep 3
    target = @browser.link(:href, "/mweb/test_cases")
    target.when_present.click
  else
    fail('mWeb module not present')
  end
end

Then /^I go to mapp test case page$/ do
  sleep 6
  if(mapp_dashboard_link.present?)
    mapp_dashboard_link.hover
    sleep 3
    target = @browser.link(:href, "/mapp/test_cases")
    target.when_present.click
  else
    fail('mApp module not present')
  end
end

Then /^I go to service test case page$/ do
  sleep 6
  if(service_dashboard_link.present?)
    service_dashboard_link.hover
    sleep 3
    target = @browser.link(:href, "/service/test_cases")
    target.when_present.click
  else
    fail('Service module not present')
  end
end


And /^I click on add folder$/ do
  sleep 4
  add_folder_link.when_present.click
  sleep 4
end

And /^I click on add folder for mweb$/ do
  sleep 4
  mweb_add_folder_link.when_present.click
  sleep 4
end

And /^I click on add folder for mapp$/ do
  sleep 4
  mapp_add_folder_link.when_present.click
  sleep 4
end

And /^I click on add folder for service$/ do
  sleep 4
  service_add_folder_link.when_present.click
  sleep 4
end

Given /^I am on Test Category form$/ do
  sleep 10
  @browser.text.include?"Add Test Category"
  unless web_category_name && web_category_description
    fail('Add Test Category form is not open')
  end
end

Given /^I am on mweb Test Category form$/ do
  sleep 10
  @browser.text.include?"Add Test Category"
  unless mweb_category_name && mweb_category_description
    fail('Add Test Category form is not open')
  end
end

Given /^I am on mapp Test Category form$/ do
  sleep 10
  @browser.text.include?"Add Test Category"
  unless mapp_category_name && mapp_category_description
    fail('Add Test Category form is not open')
  end
end

Given /^I am on service Test Category form$/ do
  sleep 10
  @browser.text.include?"Add Test Category"
  unless service_category_name && service_category_description
    fail('Add Test Category form is not open')
  end
end

When /^I fill in Name with "(.*?)"$/ do |name|

  name = @variable_group["test_category_name"] ?  @variable_group["test_category_name"] : fail('Please define test category name value in test variable with key "test_category_name" ')
  sleep 10
  if(web_category_name.present?)
    web_category_name.set(name)
  elsif(mweb_category_name.present?)
    mweb_category_name.set(name)
  elsif(mapp_category_name.present?)
    mapp_category_name.set(name)
  elsif(service_category_name.present?)
    service_category_name.set(name)
  else
    fail('Not a valid form')
  end
end

When /^I fill in Test Case Name with "(.*?)"$/ do |name|
  name = @variable_group["test_case_name"] ?  @variable_group["test_case_name"] : fail('Please define test case name value in test variable with key "test_case_name" ')
  sleep 10

  if(web_case_name.present?)
    web_case_name.set(name)
  elsif(mweb_case_name.present?)
    mweb_case_name.set(name)
  elsif(mapp_case_name.present?)
    mapp_case_name.set(name)
  elsif(service_case_name.present?)
    service_case_name.set(name)
  else
    fail('Not a valid form')
  end


end

And /^I Click Save$/ do
  submit_element.click
  sleep 5
end


Then /^I should see "(.*?)" on sidebar$/ do |name|
  unless @browser.text.include?name
    fail('Category was not created')
  end
end

Given /^I am on test category "(.*?)" show page$/ do |name|
  name = @variable_group['test_category_name'] ?  @variable_group['test_category_name'] : fail("Please define test category name value in test variable with key 'test_category_name' " )
  category_link = sidebar_test_category_link(name)
  sleep 10
  if category_link.present?
    category_link.click
    sleep 5
    unless add_test_case_element
      fail('Not on test category show page')
    end
  end
end

Given /^I am on test case "(.*?)" show page$/ do |name|
  name = @variable_group['test_case_name'] ?  @variable_group['test_case_name'] : fail("Please define test case name value in test variable with key 'test_case_name' " )

  case_link = sidebar_test_case_link(name)
  if case_link.present?
    case_link.click
    sleep 5
    unless create_script_ele
      fail('Not on Test Case show page')
    end
  end
end

When /^I click on Add test case link$/ do
  add_test_case_element.when_present.click
end

When /^I click on Add test case link for mweb$/ do
  mweb_add_test_case_element.when_present.click
end

When /^I click on Add test case link for mapp$/ do
  mapp_add_test_case_element.when_present.click
end

When /^I click on Add test case link for service$/ do
  service_add_test_case_element.when_present.click
end

Given /^I am on test case form$/ do
  @browser.text.include?"Add Test Category"
  unless web_case_name && web_case_description
    fail('Add Test Case form is not open')
  end
end

Given /^I am on mweb test case form$/ do
  @browser.text.include?"Add Test Category"
  unless mweb_case_name && mweb_case_description
    fail('Add Test Case form is not open')
  end
end

Given /^I am on mapp test case form$/ do
  @browser.text.include?"Add Test Category"
  unless mapp_case_name && mapp_case_description
    fail('Add Test Case form is not open')
  end
end

Given /^I am on service test case form$/ do
  @browser.text.include?"Add Test Category"
  unless service_case_name && service_case_description
    fail('Add Test Case form is not open')
  end
end


Given /^I am on test case show page$/ do
  unless create_script_ele
    fail('Not on Test Case show page')
  end
end

When /^I click on Create Script link$/ do
  create_script_ele.when_present.click
end

Then /^I fill in Script Name with "(.*?)"$/ do |name|
  name = @variable_group["script_name"] ?  @variable_group["script_name"] : fail('Please define script name value in test variable with key "script_name" ')
  script_name_element.set(name)
end

Then /^I maximize browser window$/ do
  @browser.driver.manage.window.maximize
end

When /^I click on script delete$/ do
  #make sure link is visible
  scrollPageToTop
  script_delete_link.when_present.click
end

Then /^I should see browser alert confirming script delete$/ do
  sleep 4
  if !(@browser.alert.exists? && (@browser.alert.text == "Are you sure?"))
    fail('Did not get confirmation box')
  end
end

Then /^I should see browser alert confirming test delete$/ do
  sleep 4
  if !(@browser.alert.exists? && (@browser.alert.text == "Do you really want to delete this?"))
    fail('Did not get confirmation box')
  end
end

When /^I click on test case delete$/ do
  scrollPageToTop
  testcase_delete_link.when_present.click
end

When /^I click on test category delete$/ do
  scrollPageToTop
  testcategory_delete_link.when_present.click
end


Then /^I should not see text "([^"]*)"$/ do |text|
  message_text = @variable_group[text] ?  @variable_group[text] : fail("Please define #{text.humanize} value in test variable with key #{text}" )
  sleep 10
  if @browser.text.include? message_text
    fail("Found text #{message_text}")
  end
end


def mweb_dashboard_link
  @browser.link(:href, "/mweb/dashboard")
end

def mapp_dashboard_link
  @browser.link(:href, "/mapp/dashboard")
end

def service_dashboard_link
  @browser.link(:href, "/service/dashboard")
end

def scrollPageToTop
  @browser.execute_script('window.scrollTo(1000,0)')
end


def sidebar_test_category_link name
  @browser.link(:href => /test_categories/, :text => name)
end

def sidebar_test_case_link name
  @browser.link(:href => /test_cases/, :text => name)
end

def testcategory_delete_link
  delete_link = @browser.link(:data_entity => "test_category",:text => "Delete")
  if delete_link.present?
    return delete_link
  else
    fail('Test Category deletion link could not be found')
  end
end

def testcase_delete_link
  delete_link = @browser.link(:data_entity => "test_case",:text => "Delete")
  if delete_link.present?
    return delete_link
  else
    fail('Test Case deletion link could not be found')
  end
end

def script_name_element
  if @browser.text_field(:name => "script_file").wait_until_present
    @browser.text_field(:name => "script_file")
  end
end

def script_delete_link
  delete_link = @browser.link(:href => /script_versions/, :data_method => "delete")
  if delete_link.present?
    return delete_link
  else
    fail('Script deletion link could not be found')
  end
end

def create_script_ele
  @browser.execute_script('window.scrollTo(0,0)')
  script_ele = @browser.link(:href, /new_script/)
  return script_ele
end

def add_test_case_element
  @browser.link(:href, /web\/test_cases\/new/)
end

def mweb_add_test_case_element
  @browser.link(:href, /mweb\/test_cases\/new/)
end

def mapp_add_test_case_element
  @browser.link(:href, /mapp\/test_cases\/new/)
end

def service_add_test_case_element
  @browser.link(:href, /service\/test_cases\/new/)
end

def add_folder_link
  @browser.link(:href, "/web/test_categories/new")
end

def mweb_add_folder_link
  @browser.link(:href, "/mweb/test_categories/new")
end

def mapp_add_folder_link
  @browser.link(:href, "/mapp/test_categories/new")
end

def service_add_folder_link
  @browser.link(:href, "/service/test_categories/new")
end

def submit_element
  @browser.button(:type, "submit")
end

def web_category_name
  @browser.text_field(:name => "regression_test_test_category[name]")
end
def web_category_description
  @browser.text_field(:name => "regression_test_test_category[description]")
end

def web_case_name
  @browser.text_field(:name => "regression_test_test_case[name]")
end

def web_case_description
  @browser.text_field(:name => "regression_test_test_case[description]")
end

def mweb_category_name
  @browser.text_field(:name => "mobile_web_app_test_category[name]")
end

def mweb_category_description
  @browser.text_field(:name => "mobile_web_app_test_category[description]")
end

def mweb_case_name
  @browser.text_field(:name => "mobile_web_app_test_case[name]")
end

def mweb_case_description
  @browser.text_field(:name => "mobile_web_app_test_case[description]")
end

def mapp_category_name
  @browser.text_field(:name => "mobile_native_app_test_category[name]")
end

def mapp_category_description
  @browser.text_field(:name => "mobile_native_app_test_category[description]")
end

def mapp_case_name
  @browser.text_field(:name => "mobile_native_app_test_case[name]")
end

def mapp_case_description
  @browser.text_field(:name => "mobile_native_app_test_case[description]")
end

def service_category_name
  @browser.text_field(:name => "service_test_category[name]")
end

def service_category_description
  @browser.text_field(:name => "service_test_category[description]")
end

def service_case_name
  @browser.text_field(:name => "service_test_case[name]")
end

def service_case_description
  @browser.text_field(:name => "service_test_case[description]")
end

def username_element
  @browser.text_field(:name => "user_session[login]")
end

def password_element
  @browser.text_field(:name => "user_session[password]")
end

def login_element
  @browser.input(:name => "submit")
end