



Then(/^I open my browser$/) do
  require 'rubygems'
  require 'watir-webdriver'
  require 'date'
  @browser = Watir::Browser.new
end

Then(/^maximize browser$/) do
  @browser.window.maximize
end

Then(/^I clear cookies$/) do
  @browser.cookies.clear
end

Then(/^I go to "([^"]*)"$/) do |arg1|
  @browser.goto "#{arg1}"
end


Then(/^I enter "([^"]*)" in text field with id "([^"]*)"$/) do |arg1, arg2|
  begin	
  @browser.text_field(:id,"#{arg2}").when_present.set("#{arg1}")
  rescue
    @browser.text_field(:id,"#{arg2}")[2].when_present.set("#{arg1}")
  end
end

Then(/^I click button with id "([^"]*)"$/) do |arg1|
  @browser.button(:id,"#{arg1}").when_present.click
end

Then(/^I click button with value "([^"]*)"$/) do |arg1|
  @browser.button(:value,"#{arg1}").when_present.click
end
#LOG IN TO BB

Then(/^I enter "([^"]*)" in the text field with id "([^"]*)"$/) do |arg1, arg2|
  @browser.text_field(:id,"#{arg2}").when_present.set("#{arg1}")
end 
  
  
  Then(/^I click link with id "([^"]*)"$/) do |arg1|
  @browser.a(:id,"#{arg1}").when_present.click
end

  Then(/^I click span with text "([^"]*)"$/) do |arg1|
  @browser.span(:text,"#{arg1}").when_present.click
end

 Then(/^I click div with text "([^"]*)"$/) do |arg1|
  @browser.div(:text,"#{arg1}").when_present.click
end

 Then(/^I click image with id "([^"]*)"$/) do |arg1|
  @browser.image(:src,"#{arg1}").when_present.click
end

 Then(/^I click link with classname "([^"]*)"$/) do |arg1|
  @browser.class(:id,"#{arg1}").when_present.click
end

 Then(/^I click button with name "([^"]*)"$/) do |arg1|
  @browser.button(:name,"#{arg1}").when_present.click
end

  Then(/^I click link with href "([^"]*)"$/) do |arg1|
  @browser.a(:href,"#{arg1}").when_present.click
end

#Navigate to Transfer Funds

Then(/^I select "([^"]*)" from list with id "([^"]*)"$/) do |arg1, arg2|
  @browser.select_list(:id,"#{arg2}").when_present.select("#{arg1}")

end


Then(/^I click list "([^"]*)" from form with id "([^"]*)"$/) do |arg1, arg2|
  @browser.form(:id,"#{arg2}").select_list(:id,"#{arg1}").when_present.click

end

Then(/^I choose "([^"]*)" from list with id "([^"]*)" in form (.*?)"$/) do |arg1, arg2, arg3|
  @browser.form(:id,"#{arg3}").select_list(:id,"#{arg2}").when_present.select("#{arg1}")

end

Then(/^I pick value "([^"]*)" from list with id "([^"]*)"$/) do |arg1, arg2|

  @browser.select_list(id: arg2).when_present.select_value(arg1)

end

Then(/^I click button with value "([^"]*)" in form (.*?)"$/) do |arg1, arg2|
  @browser.form(:id,"#{arg2}").button(:value,"#{arg1}").when_present.click

end

Then(/^I select value "([^"]*)" from list with id "([^"]*)"$/) do |arg1, arg2|
  @browser.select_list(:id,"#{arg2}").when_present.select_value("#{arg1}")

end

Then(/^I enter "([^"]*)" in text field "([^"]*)" in frame "([^"]*)"$/) do |arg1, arg2, arg3|
 @browser.iframe(:id,"#{arg3}").text_field(:id,"#{arg2}").when_present.set("#{arg1}")
end 

Then(/^I enter "([^"]*)" in text field "([^"]*)" in form "([^"]*)"$/) do |arg1, arg2, arg3|
 @browser.form(:id,"#{arg3}").text_field(:id,"#{arg2}").when_present.set("#{arg1}")
end

Then(/^I click on button with id "([^"]*)" in frame "([^"]*)"$/) do |arg1, arg2,|
 @browser.iframe(:id,"#{arg2}").button(:id,"#{arg1}").when_present.click
end

Then(/^I select "([^"]*)" from list with name "([^"]*)"$/) do |arg1, arg2|
  @browser.select_list(:name,"#{arg2}").when_present.select("#{arg1}")

end

Then(/^I hover over link with text "([^"]*)"$/) do |arg1|
  @browser.a(:text,"#{arg1}").when_present.hover
end

Then(/^I hover over "([^"]*)" until I see "([^"]*)"$/) do |arg1, arg2|
  done = false
  count = 0
 while not done && count != 10
	  find_el(arg1).when_present.hover
	  find_els(arg2).each do  | el|
		if el.visible?
			done = true
			break
		end
	  end
   count =count + 1
   end
end


Then(/^I click button with text "([^"]*)"$/) do |arg1|
  @browser.button(:text,"#{arg1}").when_present.click
end

Then(/^I click with xpath "([^"]*)"$/) do |arg1|
  @browser.xpath("#{arg1}").when_present.click
end

Then(/^I click element with text "([^"]*)"$/) do |arg1|
  @browser.element(:text,"#{arg1}").when_present.click
end

Then(/^I click element with classy "([^"]*)"$/) do |arg1|
  @browser.element(:class,"#{arg1}").when_present.click
end

Then(/^I click element with id "([^"]*)"$/) do |arg1|
  @browser.element(:id,"#{arg1}").when_present.click
end

Then(/^I click element with value "([^"]*)"$/) do |arg1|
  @browser.element(:value,"#{arg1}").when_present.click
end


  Then(/^I click link with text "([^"]*)"$/) do |arg1|
  begin
  @browser.a(:text,"#{arg1}").when_present.click
  rescue 
  @browser.as(:text,"#{arg1}")[0].click
  end
end

Then(/^I click text field with id "([^"]*)"$/) do |arg1|
  @browser.text_field(:id,"#{arg1}").when_present.click 
end

Then(/^I click list component "([^"]*)"$/) do |arg1|
  @browser.li(:text, /#{arg1}/).when_present.click
end

Then(/^I click list component with value "([^"]*)"$/) do |arg1|
  @browser.li(:value, /#{arg1}/).when_present.click
end

Then(/^I click list component with id "([^"]*)"$/) do |arg1|
  @browser.li(:id, /#{arg1}/).when_present.click
end


Then (/^I enter date in the field with id "([^"]*)"$/) do |arg1|
d = Date.today
$Today_Date = "#{d.strftime("%m")}/#{d.strftime("%d")}/#{d.year}"
  @browser.text_field(:id,"#{arg1}").when_present.set("#{$Today_Date}")
end



Then(/^I tab out$/) do
  @browser.send_keys :tab
end


Then(/^I enter "([^"]*)" into text field with id "([^"]*)"$/) do |arg1, arg2|
  pending # express the regexp above with the code you wish you had
end
  
  Then (/^I enter date plus one in the field with id "([^"]*)"$/) do |arg1|
d = Date.today + 1
$Tomorrow_Date = "#{d.strftime("%m")}/#{d.strftime("%d")}/#{d.year}"
  @browser.text_field(:id,"#{arg1}").when_present.set("#{$Tomorrow_Date}")
end  


Then /^allow me to debug$|^pry$|^execute binding.pry$/ do
  require 'pry'
  binding.pry
end

#Set based on Name
 Then(/^I enter "([^"]*)" in the text field with name "([^"]*)"$/) do |arg1, arg2|
  @browser.text_field(:name,"#{arg2}").when_present.set("#{arg1}")
end 


Then(/^I click checkbox with name "([^"]*)"$/) do |arg1|
  @browser.checkbox(:name,"#{arg1}").set(true)
end
