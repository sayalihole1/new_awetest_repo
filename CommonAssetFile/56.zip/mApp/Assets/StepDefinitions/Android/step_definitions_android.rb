Then /^I order all items$/ do
  step "I toggle checkbox number 1"
  step "I enter \"1\" into input field number 1"
   step "I toggle checkbox number 2"
  step "I enter \"1\" into input field number 2"
   step "I toggle checkbox number 3"
  step "I enter \"1\" into input field number 3"
   step "I toggle checkbox number 4"
  step "I enter \"1\" into input field number 4"
  step "I touch the \"Proceed to Order\" text"
  sleep 2
  step "I see \"Total = 100\""
end