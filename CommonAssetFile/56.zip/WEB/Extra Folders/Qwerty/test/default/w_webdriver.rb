require 'rubygems'
require 'watir-webdriver'
b = Watir::Browser.new
b.goto("www.google.com")
b.text_field(:name, "q").set("3qilabs")
b.button(:name, "btnG").click
b.text.include? "3QI Labs"
b.close