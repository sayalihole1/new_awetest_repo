Given /^I open a new browser$/ do
end
