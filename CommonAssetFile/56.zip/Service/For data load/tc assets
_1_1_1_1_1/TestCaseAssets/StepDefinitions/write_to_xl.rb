After do |scenario|
  # if scenario.failed?
  #req_header = ActiveSupport::JSON.decode(@req_header.to_s)
  req_header = JSON.pretty_generate @req_header rescue @req_header.to_s
  act_resp = ActiveSupport::JSON.decode(@act_resp) rescue @act_resp
  act_resp = JSON.pretty_generate act_resp rescue act_resp
  @failing_error = scenario.exception.to_s if (!@failing_error || @failing_error.empty?) && scenario.exception
  payload = ActiveSupport::JSON.decode(@req_param) rescue @req_param
  payload = JSON.pretty_generate payload rescue @req_param
  expected_resp = ActiveSupport::JSON.decode(@resp_param) rescue @resp_param
  expected_resp = JSON.pretty_generate expected_resp rescue expected_resp
  result = scenario.failed? ? "Fail" : "Pass"
  resp_too_long = act_resp.length > 32001 rescue false
  act_resp = resp_too_long ? act_resp[0..32000] : act_resp
  note = resp_too_long ? 'complete response is too long, only first part is available' : ''
  db_resp_array = @db_resp_array rescue [['a', 'aaa'], ['b', 'bbb']]
  # db_resp_array = [['a', 'aaa'], ['b', 'bbb']]
  # db_resp_array = 'ArrayHere8'
  $act_resp_data_val.push [@row_id, @test_element, @scenario, result, Time.now.to_s, @url, @request_type, req_header, payload, expected_resp, act_resp, @exp_header, @act_resp_headers.to_s, @response_time, @exp_code, @act_code, @failing_error, note, db_resp_array]
  # end
end

Before do
  if $act_resp_data_val.nil?
    $act_resp_data_val =[["ID", "Element", "Scenario", "Result", "Date/Time", "URL", "Method", "Headers", "Payload", "Expected Response", "Actual Response", "Expected Headers", "Actual Headers", "Time(s)", "Exp Code", "Act Code", "Issue", "Note", "DB Response"]]
  end
end

at_exit do
  book = Spreadsheet::Workbook.new
  sheet1 = book.create_worksheet
  for i in 0..$act_resp_data_val.length - 1
    sheet1.row(i).push i, *$act_resp_data_val[i]
  end
  @myRoot = File.join(File.dirname(__FILE__), '/')
  `mkdir #{@myRoot}../../awetest_report`
  puts "#{@myRoot}../../awetest_report/#{$data_changes_for}_#{Time.now.strftime "%d_%m_%H_%M_%S"}_.xls"
  book.write "#{@myRoot}../../awetest_report/__#{$data_changes_for}_#{Time.now.strftime "%d_%m_%H_%M_%S"}_.xls"

  # Create Html Report
  html_string = ''
  html_string << get_html_header_string
  for i in 1..$act_resp_data_val.length - 1
    html_string << write_each_line_to_report($act_resp_data_val[i], i)
  end
  html_string << get_html_footer_string
  File.open("#{@myRoot}../../awetest_report/__#{$data_changes_for}_#{Time.now.strftime "%d_%m_%H_%M_%S"}_.html", 'w') {|file| file.write(html_string)}

  # Create Json Report
  # require 'json'
  json_hash = {}
  for i in 1..$act_resp_data_val.length - 1
    json_hash[i] = {}
    for j in 0...$act_resp_data_val[0].length
      json_hash[i][$act_resp_data_val[0][j]] = $act_resp_data_val[i][j]
    end
  end
  File.open("#{@myRoot}../../awetest_report/__#{$data_changes_for}_#{Time.now.strftime "%d_%m_%H_%M_%S"}_.json", 'w') {|file| file.write(json_hash.to_json)}

end

def get_html_header_string
  return '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Fat Free CRM API Automation Test</title>

    <link href="https://awetest.com/system/downloads/Report/style.css" rel="stylesheet"/>

    <script   src="https://code.jquery.com/jquery-3.1.1.min.js"   integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="   crossorigin="anonymous"></script>
		<script src="https://awetest.com/system/downloads/Report/clipboard.min.js"></script>
    <script src="https://awetest.com/system/downloads/Report/Chart.js"></script>
    <script type="text/javascript" src="https://awetest.com/system/downloads/Report/awetest_part.js"></script>
    <!--[if IE]>
    <style>
        .inner-table-wrapper {
            position: relative;
            left: -1px;
        }
    </style>
    <![endif]-->

</head>
<body>
<header class="header"></header>
<div class="left-tab"></div>
<div class="wrapper">
    <div class="content">
        <div class="row">
            <div class="gl_page_inner">
                <div class="gl_hr_header">
                    <div class="header-element"><a href="" class="header-element-link">Test Report</a></div>
                </div>
                <div class="design-body">
                    <div class="information-block">
                        <div class="inf-bottom-part">
                            <div class="main-info-wrapper">
                                <div>
                                    <span class="sprite sprite-i-multi-storey-building-white"></span>Total Time: <span id="total-time"></span> Seconds
                                </div>
                                <div>
                                    <span class="sprite sprite-i-multi-storey-building-white"></span># of Scenarios: <span id="total-scenario-number"></span>
                                </div>
                                <div>
                                    <span class="sprite sprite-i-multi-storey-building-white"></span>
                                </div>
                                <div><span class="sprite sprite-i-multi-storey-building-white"></span># Passed: <span id="passed-scenario-number"></span></div>
                                <div>
                                    <span class="sprite sprite-i-multi-storey-building-white"></span>
                                </div>
                                <div><span class="sprite sprite-i-multi-storey-building-white"></span>Pass %: <span id="pass-percentage"></span></div>
                            </div>
                            <div class="chart-wrapper">
                                <canvas id="chart1" height="120px" width="120px"></canvas>
                                <div class="chartjs-tooltip" id="chart-tooltip"></div>
                                <div id="spfg_legend"></div>
                            </div>
                        </div>
                    </div>

                    <div class="information-table">
                        <div class="table-control-row">
                            <p class="active left-control expand-button closed" data-target="all">EXPAND ALL</p>
                            <p class="right-control toggle-errors active">ALL</p>
                            <p class="right-control toggle-errors">ERRORS</p>
                            <p class="right-control">SHOW</p>
                        </div>

                        <table class="inf-table">
                            <thead class="table-head">
                            <tr>
                                <th width="39">#</th>
                                <th width="80">ID</th>
                                <th width="121">URL</th>
                                <th width="230">Scenario</th>
                                <th width="96">Date/Time</th>
                                <th width="67">Method</th>
                                <th width="90">Duration</th>
                                <th width="86">Exp Code</th>
                                <th width="86">Actual Code</th>
                                <th width="88">Result</th>
                            </tr>
                            </thead>

                            <tbody>'
end

def write_each_line_to_report (report_line, i)
  result_string = ""

  if report_line[3] == 'Pass'
    result_string << "<tr class='pass scenario' id='scenario#{i}'>"
  else
    result_string << "<tr class='fail scenario' id='scenario#{i}'>"
  end

  result_string << "
                                    <td width='39'>
                                        <div class='jump-wrapper'>
                                            <div data-destination='#scenario#{i-1}'>↑</div>
                                            <div data-destination='#scenario#{i+1}'>↓</div>
                                        </div>
                                        <span class='expand-button closed' data-target='.expand-#{i}'></span>#{i}
                                    </td>
                                    <td width='80'>#{i}</td>
                                    <td width='121'><a href='#{report_line[5]}' class='table-link'>#{report_line[5]}</a></td>
                                    <td width='235'>#{report_line[0]}</td>
                                    <td width='96'>#{report_line[4]}</td>
                                    <td width='67'>#{report_line[6]}</td>
                                    <td width='90' class='single-scenario-time'>#{report_line[13]}</td>
                                    <td width='86'>#{report_line[14]}</td>
                                    <td width='86'>#{report_line[15]}</td>"

  if report_line[3] == 'Pass'
    result_string << "<td width='90' class='result-pass result-count pass-count'><span class='sprite sprite-i-passed-green'></span>#{report_line[3]}</td>"
  else
    result_string << "<td width='90' class='result-fail result-count fail-count'><span class='sprite sprite-i-failed-red'></span>#{report_line[3]}</td>"
  end

  result_string << "<tr class='expand-row'>
      <td class='no-padding no-border' colspan='10'>
          <div class='inner-table-wrapper expand-#{i} hide'>"

  if 1 + 1 > 2
    result_string << "<div class='comment-text'>What is this?
              </div>"
  end

  result_string << "<span class='tab-toggle summary active'>Summary</span>
              <span class='tab-toggle log'>Log</span>
              <span class='tab-toggle xml'>Xml</span>
              <div class='log-with-scroll hidden'>"

  for item in report_line[18].to_a
    result_string << "#{item[0]}:<br>#{item[1]}<br><br>"
  end

  result_string <<             "</div>
              <table class='inf-table'>
                  <tr>
                      <th>Request</th>
                      <th>Expected Response</th>
                      <th>Actual Response</th>
                  </tr>"

  if report_line[3] == 'Pass'
  else
    result_string << "<tr>
												<td class='error-row' colspan='3'>Error: TODO</td>
                                                </tr>"
  end

  result_string << "<tr>
                                        <td>
                                            <div class='tooltip copy-to-clipboard'>
                                                <div class='sprite sprite-i-list-grey ripplelink'></div>
                                                <div class='tooltip-inner'>
                                                    <div class='tooltip-ir-inner'>
                                                        Copy to clipboard
                                                    </div>
                                                </div>
                                            </div>
                                            <div class='json-wrapper'>
                                                Headers<br>
                                                <pre>#{report_line[7]}</pre>
                                            </div>
                                        </td>
                                        <td>
                                            <div class='tooltip copy-to-clipboard'>
                                                <div class='sprite sprite-i-list-grey ripplelink'></div>
                                                <div class='tooltip-inner'>
                                                    <div class='tooltip-ir-inner'>
                                                        Copy to clipboard
                                                    </div>
                                                </div>
                                            </div>
                                            <div class='json-wrapper'>
                                                Headers<br>
                                                <pre>#{report_line[11]}</pre>
                                            </div>
                                        </td>
                                        <td>
                                            <div class='tooltip copy-to-clipboard'>
                                                <div class='sprite sprite-i-list-grey ripplelink'></div>
                                                <div class='tooltip-inner'>
                                                    <div class='tooltip-ir-inner'>
                                                        Copy to clipboard
                                                    </div>
                                                </div>
                                            </div>
                                            <div class='json-wrapper'>
                                                Headers<br>
                                                <pre>#{report_line[12]}</pre>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class='tooltip copy-to-clipboard'>
                                                <div class='sprite sprite-i-list-grey ripplelink'></div>
                                                <div class='tooltip-inner'>
                                                    <div class='tooltip-ir-inner'>
                                                        Copy to clipboard
                                                    </div>
                                                </div>
                                            </div>
                                            <div class='json-wrapper'>
                                                Body<br>
                                                <pre>#{report_line[8]}</pre>
                                            </div>
                                        </td>
                                        <td>
                                            <div class='tooltip copy-to-clipboard'>
                                                <div class='sprite sprite-i-list-grey ripplelink'></div>
                                                <div class='tooltip-inner'>
                                                    <div class='tooltip-ir-inner'>
                                                        Copy to clipboard
                                                    </div>
                                                </div>
                                            </div>
                                            <div class='json-wrapper'>
                                                Body<br>
                                                <pre>#{report_line[9]}</pre>
                                            </div>
                                        </td>
                                        <td>
                                            <div class='tooltip copy-to-clipboard'>
                                                <div class='sprite sprite-i-list-grey ripplelink'></div>
                                                <div class='tooltip-inner'>
                                                    <div class='tooltip-ir-inner'>
                                                        Copy to clipboard
                                                    </div>
                                                </div>
                                            </div>
                                            <div class='json-wrapper'>
                                                Body<br>
                                                <pre>#{report_line[10]}</pre>
                                            </div>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </td>
                    </tr>"
  return result_string
end

def get_html_footer_string
  return "
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<div id='return-to-top'><i class='sprite sprite-i-dropdown-grey'></i></div>
<script type='text/javascript'>
    var totalScenarioNumber = $('.result-count').length;
    var passedScenarioNumber = $('.result-count.pass-count').length;
    var passPercentage = (passedScenarioNumber * 100 / totalScenarioNumber).toFixed(2) + '%';
    $('#total-scenario-number').html(totalScenarioNumber);
    $('#passed-scenario-number').html(passedScenarioNumber);
    $('#pass-percentage').html(passPercentage);
    var totalTimeInSecond = 0;
    $('.single-scenario-time').each(function () {
        var timeText = $(this).html();
        totalTimeInSecond += Number(timeText.split(' ')[0]);
    });
		var totalTimeInSec = Math.round(totalTimeInSecond);
    $('#total-time').html(totalTimeInSec);
</script>
</body>
</html>"
end