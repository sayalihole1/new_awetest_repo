Then /^I go to awetest$/ do
  @browser.goto "http://209.20.92.129:8080"
end


Given /^I am on a login page$/ do
  unless username_element && password_element && login_element
    fail("Not on a login page")
  end
end

When /^I fill in username and password with "([^"]*)" and "([^"]*)" respectively$/ do |username, password|
    username_element.set(username)
    password_element.set(password)
end    

Then /^The values in username and password should be "([^"]*)" and "([^"]*)" respectively$/ do |username, password|
    unless (username_element.value == username) && (password_element.value == password)
        fail("Values are not as per expectations")
    end    
end

And /^I click on Sign In$/ do
    login_element.click
end

Then /^I should see the text "(.*?)"$/ do |message|
    unless @browser.text.include?(message)
        fail("Did not find #{message} on the page")
    end    
end

def username_element
    @browser.text_field(:name => "user_session[login]")
end

def password_element
    @browser.text_field(:name => "user_session[password]")
end

def login_element
    @browser.input(:name => "submit")
end