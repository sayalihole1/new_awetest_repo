def get_open_port
  server = TCPServer.new('127.0.0.1', 0)
  port = server.addr[1]
  server.close
  port
end

def get_playback_gap_ratio(expected_time, buffering)
  result = 0
  if buffering > 0 && expected_time > 0
    result = (buffering/expected_time.to_f*100).round(2)
  end
  result
end


def convert_time_to_i(expected_time)
  expected_time = "00:#{expected_time}" if expected_time.to_s.length < 6
  new_time =Time.parse(expected_time)
  midnight = Time.local(DateTime.now.year,DateTime.now.month,DateTime.now.day,0,0,0)
  (new_time - midnight).to_i
end
def convert_time_to_s(time)
  Time.at(time).utc.strftime("%H:%M:%S").to_s + (".#{((time*1000).to_i%1000).to_s.rjust(3, "0")}")
end

def refresh_content
  #$driver.page
  $driver.get_page_class
end
def skipp_add_if_any
  add_skipped = $driver.id('com.google.android.youtube:id/skip_ad_text').click rescue false
  add_skipped ||= $driver.id('com.google.android.youtube:id/skip_button').click rescue false
  add_skipped
end
def not_timed_out?
  if Time.now < $script_complete_by
    true
  else
    puts "The set test timeout limit reached"
    raise("The set test timeout limit reached")
  end
end
def get_phone_location
  locations = `adb -s #{$device_id} shell dumpsys location`.split("\n")
  found = false
  network_location = []
  locations.each do |location|
    if found && location.include?('network:')
       network_location =  location.split(' ')
       break
    end
    found = true if location.include? 'Last Known Locations'
  end
  network_location.select! {|l| l =~ /\d+.\d+,-?\d+.\d+/}
  network_location[0].split(',') rescue []
end
def get_connection
  timeout = 30
  start = 0
  connection = ''
  while timeout > start
    network = (`adb -s #{$device_id} shell dumpsys connectivity | grep CONNECTED/CONNECTED`).split("\n").last
    if network && !network.scan(/\([^"]*\)/).empty?
      connection = network.scan(/\([^"]*\)/).first[1..-2] rescue ''
      connection = 'WIFI' if network.include? 'WIFI'
      break if connection != ''
    end
    start +=1
    sleep 1
  end

  case connection
    when 'LTE'
      connection
    when 'HSPA+', 'HSUPA'
      '3G'
    when 'EDGE'
      '2G'
    else
      connection
  end
end

def set_network_mode_get_operator(mode)
  operator = 'error'
  begin
  $driver.start_activity app_package: "com.android.phone", app_activity: ".MobileNetworkSettings"
  operator = get_operator_helper
  $driver.wait{$driver.find('Network mode').click}
  $driver.wait{$driver.find(mode).click}
  $driver.back
  sleep 5
  rescue
    if $driver.current_activity == ".MobileNetworkSettings"
      $driver.back
    end
  end
  operator
end

def get_operator
  `adb  shell -s #{$device_id} getprop gsm.operator.alpha`
end

def get_operator_helper
  result = 'error getting operator'
  found = false
  $driver.texts.each  do |text|
    if found
      result = text.text
      break
    end
    if text.text == "Network operators"
      found = true
    end
  end
  result
end

def get_location_details(location)
  result = {}
  begin
  require 'rest-client'
  require 'json'
  address = RestClient.get "http://nominatim.openstreetmap.org/reverse?format=json&lat=#{location[0]}6&lon=#{location[1]}&zoom=10&addressdetails=1&accept-language=en_us"
  result = JSON.parse(address)
  result = result['address']
  rescue 
    true
  end
  result
end

def wait_to_disappear(el)
  while not_timed_out? && ($driver.id(el) rescue false)
    refresh_content
  end
end
def wait_to_appear(el)
  while not_timed_out? && (!$driver.id(el) rescue true)
    refresh_content
  end
end

#* I run performance test for video "King Julien - New Year's Eve Countdown" on "3G only"
And(/^I run performance test for video "([^"]*)"(?: on )?"?([^"]*)?"?$/) do |video_name, network|
  #$all_results ||={}
  #$all_results[:runs] ||= []
  @run_results = {}
  @run_results[:job] = {}
  @run_results[:job][:id] = @params['log_properties']['job_id']
  #@run_results[:job][:date] = Time.now.getlocal('-08:00').strftime("%a., %m/%d/%y %l:%M %P (GMT %z)")
  @run_results[:job][:timestamp] = Time.now.to_s
  location = get_phone_location
  @run_results[:job][:location] = location
  location_details = get_location_details(location)
  @run_results[:job][:locationDetails]= location_details
  operator = get_operator
  operator = set_network_mode_get_operator(network) if network
  @run_results[:job][:provider] = operator
  @run_results[:job][:connection] = get_connection
  @run_results[:test] = {}
  @run_results[:test][:app] = @app
  @run_results[:test][:Video] = video_name


  wait = Selenium::WebDriver::Wait.new :timeout => 90
  video_name = video_name + "\n"
  begin
    $driver.driver.manage.timeouts.implicit_wait=30
    wait.until {
        $driver.back
        $driver.back
        $driver.back
        $driver.find(@app).click
        $driver.find('Search').click
    }
  refresh_content
  $driver.driver.manage.timeouts.implicit_wait=0

  if @app == 'YouTube'
    $driver.wait {$driver.id('com.google.android.youtube:id/search_edit_text').type video_name}

    sleep 5
    video_duration = nil
    begin
    #clicking on the video to start it
    wait.until {video_duration = $driver.id('com.google.android.youtube:id/duration').text.rjust(5, "0")
        $driver.id('com.google.android.youtube:id/thumbnail').click}
    rescue
      raise('Could not find the video, Search results did not load')
    end

    puts "starting video"
    #$driver.find_element(name: 'Replay video').click rescue nil
    start_time = Time.now
    actual_start_time = Time.now

    #wait for video to start, will break if started
    while not_timed_out?
      refresh_content
      while not_timed_out? && ($driver.id('com.google.android.youtube:id/player_loading_view') rescue false)
        actual_start_time = Time.now
        break if ($driver.id('com.google.android.youtube:id/skip_button') rescue false)
        refresh_content
      end
      video_started = ($driver.id('com.google.android.youtube:id/time_bar').name =~ /0:0\d of #{video_duration}$/) rescue true
      #check if error present
      unless video_started
        error_occured = $driver.find('An error occurred').click rescue false
        actual_start_time = Time.now if error_occured
      end
      #check if add present
      while not_timed_out? && !video_started && ((($driver.id('com.google.android.youtube:id/player_learn_more_button') rescue false) || ($driver.id('com.google.android.youtube:id/skip_button') rescue false)))
        video_started = false

        print '!'
        actual_start_time = Time.now
        start_time = Time.now
        add_skipped = skipp_add_if_any
        if add_skipped
        start_time = Time.now
        actual_start_time = Time.now
        end
        refresh_content
      end
      break if video_started
      print '.'

    end
    time_to_load_video = actual_start_time - start_time

    video_play_click = $driver.find_element(name: 'Play video').click rescue false
    actual_start_time = Time.now if video_play_click
    puts 'video started'
    #current_time = $driver.id('com.google.android.youtube:id/time_bar').text

    loading_data = []
    #wait until play_pause button disappears
    while not_timed_out? && (($driver.id('com.google.android.youtube:id/player_control_play_pause_replay_button') rescue false))
      refresh_content
    end
    #while no play_pause button, we are in the video, checking for buffering...
    while not_timed_out? && !(($driver.find_element(name: 'Replay video')rescue false) || ($driver.find_element(name: 'Play video') rescue false)) #while video is not done
      #while not_timed_out? && !(($driver.id('com.google.android.youtube:id/player_control_play_pause_replay_button') rescue false))
      refresh_content
      loading = $driver.id('com.google.android.youtube:id/player_loading_view') rescue false
      if loading
        loading_start_time = Time.now - actual_start_time
        puts 'buffering...'
        while not_timed_out? && ($driver.id('com.google.android.youtube:id/player_loading_view') rescue false)
          refresh_content
        end

        loading_end_time = Time.now - actual_start_time
        load_total_time = loading_end_time - loading_start_time
        loading_data << [loading_start_time.to_s, loading_end_time.to_s, load_total_time]
        puts 'playback resumed...'
      end
    end

    actual_played = Time.now - actual_start_time  #0.5 to 1 second delay before we know video stopeed.#- 0.5 #remove  -0.5 once using other while
    expected_time = $driver.id('com.google.android.youtube:id/time_bar').text
    expected_time = convert_time_to_i(expected_time)
    video_total_time = $driver.id('com.google.android.youtube:id/time_bar').name
    video_total_time = convert_time_to_i(video_total_time)

  # ============= NETFLIX =========
  elsif @app == 'Netflix'
    $driver.wait {$driver.id('android:id/search_src_text').type video_name}
    sleep 5

    begin
      wait.until {$driver.id('com.netflix.mediaclient:id/search_result_img').click}
      $driver.wait {$driver.id('com.netflix.mediaclient:id/video_img').click}
    rescue
      raise('Could not find the video, Search results did not load')
    end
    print "Loading video"
    #$driver.find_element(name: 'Replay video').click rescue nil
    start_time = Time.now
    while not_timed_out? && ($driver.id('com.netflix.mediaclient:id/playoutSplash') rescue false)
      refresh_content
      print '.'
    end
    actual_start_time = Time.now
    time_to_load_video = actual_start_time - start_time
    puts "video started"
    expected_time = $driver.id('com.netflix.mediaclient:id/label_duration').text
    expected_time = convert_time_to_i(expected_time)
    #current_time = $driver.id('com.google.android.youtube:id/time_bar').text

    loading_data = []
    while not_timed_out? && (($driver.id('com.netflix.mediaclient:id/playoutPlay') rescue false))
      refresh_content
      loading = $driver.id('com.netflix.mediaclient:id/splash_buffering') rescue false
      if loading
        loading_start_time = Time.now - actual_start_time
        puts 'buffering...'
        while not_timed_out? && ($driver.id('com.netflix.mediaclient:id/splash_buffering') rescue false)
          refresh_content
        end

        loading_end_time = Time.now - actual_start_time
        load_total_time = loading_end_time - loading_start_time
        loading_data << [loading_start_time.to_s, loading_end_time.to_s, load_total_time]
        puts 'playback resumed...'
      end
    end
    video_total_time = expected_time
    actual_played = Time.now - actual_start_time #- 0.5 #remove  -0.5 once using other while


  # ============= Crackle =========
  elsif @app == 'Crackle'
    buffering_id = 'com.gotv.crackle.handset:id/progress_indicator'
    search_box_id = 'android:id/search_src_text'
    video_img_id = 'com.gotv.crackle.handset:id/main_button'
    video_section_id = 'com.gotv.crackle.handset:id/group_title'
    video_container_id = 'com.gotv.crackle.handset:id/mainVideoContainer' # add / video
    video_id = 'com.gotv.crackle.handset:id/videoView' # video only
    video_playing_id = 'com.gotv.crackle.handset:id/network_id'
    $driver.wait {$driver.id(search_box_id).type video_name}
    $driver.driver.manage.timeouts.implicit_wait=0
    sleep 5

    begin
      wait.until {$driver.id(video_img_id).click}

    rescue
      raise('Could not find the video, Search results did not load')
    end
    sleep 1
    wait.until {!$driver.id('com.gotv.crackle.handset:id/loading_progress') rescue true}
    $driver.wait {$driver.find('Browse Episodes').click}
    $driver.wait {$driver.ids(video_section_id).last.click}
    $driver.wait {$driver.ids('com.gotv.crackle.handset:id/play_button').last.click}
    print "waiting for add video"
    start_time = Time.now
    ##waiting for an add to show up
    while not_timed_out? && (!$driver.id(video_container_id) rescue true)
      $driver.find_exact('Start Over').click rescue nil
      refresh_content
    end
    add_loaded_time = Time.now
    time_to_load_add = add_loaded_time - start_time

    #waiting for ad. to finish
    wait_to_appear(video_id)
    #ad. finished.
    start_time = Time.now
    #print "Loading video"
    ##waiting for initial buffering
    wait_to_disappear(buffering_id)
    wait_to_appear(video_playing_id)

    actual_start_time = Time.now
    time_to_load_video = actual_start_time - start_time
    puts "video started"
    $driver.id(video_id).click
    expected_time = nil



    #current_time = $driver.id('com.google.android.youtube:id/time_bar').text

    loading_data = []
    while not_timed_out? &&  (!expected_time || (($driver.id(video_id) rescue false)))
      #try getting expected time
      unless expected_time
        begin
          unless ($driver.id('com.gotv.crackle.handset:id/buttonPausePlay') rescue false)
            $driver.id(video_id).click
          end
          #binding.pry
          time_played = $driver.id('com.gotv.crackle.handset:id/time_played').text
          time_remaining = $driver.id('com.gotv.crackle.handset:id/time_remaining').text
          time_played_1 = $driver.id('com.gotv.crackle.handset:id/time_played').text
          #capturing time can take up to 1 second
          if time_played == time_played_1
            time_played = convert_time_to_i(time_played)
            time_remaining = convert_time_to_i(time_remaining)
            expected_time = time_played + time_remaining
          end
        rescue
          true
        end
      end
      refresh_content
      loading = $driver.id(buffering_id) rescue false
      if loading
        loading_start_time = Time.now - actual_start_time
        #puts 'buffering...'
        wait_to_disappear(buffering_id)

        loading_end_time = Time.now - actual_start_time
        load_total_time = loading_end_time - loading_start_time
        loading_data << [loading_start_time.to_s, loading_end_time.to_s, load_total_time]
        #puts 'playback resumed...'
      end
    end
    video_total_time = expected_time
    actual_played = Time.now - actual_start_time #- 0.5 #remove  -0.5 once using other while

  else
    raise("unimplemented app #{@app}")
  end

  # ===========REPORT==============
  actual_played -= 1 unless @app == "Crackle"# !!! Adjust for actual play time

  puts "Actual video time played: " + convert_time_to_s(actual_played)
  puts "Loading before start: " + convert_time_to_s(time_to_load_video)
  total_buffering = (actual_played - expected_time).round(3)
  ratio = get_playback_gap_ratio(expected_time, total_buffering)
  puts "Video total time #{convert_time_to_s(video_total_time)}"
  puts "  Based on captured buffering:"
  puts "    Loading while playing:"
  total_buffering_captured = 0
  loading_data.each do |loading|
    total_buffering_captured += loading[2]
    puts "Buffering from #{convert_time_to_s(loading[0].to_f)} until #{convert_time_to_s(loading[1].to_f)}. duration: #{convert_time_to_s(loading[2])} "
    loading[2]= loading[2].round(3).to_s
  end
  ratio_captured = get_playback_gap_ratio(expected_time, total_buffering_captured)
  puts "    Total Buffering was: #{total_buffering_captured.round(2)} seconds"
  puts "    Video buffering time: #{ratio_captured}%"
  puts "  Double check Based on video length:"
  puts "    Total Buffering was: #{total_buffering.round(2)} seconds"
  puts "    Video buffering time: #{ratio}%"

  #json report
  3.times {
    $driver.back
  }
  @run_results[:test][:status] = "Completed"
  @run_results[:test][:videoDuration] = expected_time.to_s
  @run_results[:test][:videoLoadTime] = time_to_load_video.to_s
  @run_results[:test][:totalRunTime] = actual_played.to_s
  @run_results[:test][:runTimeOverage] = total_buffering.to_s
  @run_results[:test][:runTimeGapRation] = ratio.to_s
  @run_results[:test][:bufferingsCount] = loading_data.length
  @run_results[:test][:bufferingIconPresent] = total_buffering_captured.round(3).to_s
  @run_results[:test][:bufferingGapRatio] = ratio_captured.to_s
  @run_results[:test][:bufferingsDetails] = loading_data
  total_buffering = 0   if total_buffering < 0
  @run_results[:test][:totalRunTimeGapRatio] = get_playback_gap_ratio(expected_time, time_to_load_video + total_buffering).to_s
  @run_results[:test][:totalBufferingGapRatio] = get_playback_gap_ratio(expected_time, time_to_load_video + total_buffering_captured).to_s


  rescue => e
    puts "Error occured\n #{e.to_s}"
    @run_results[:test][:status] = "Error"
    @run_results[:test][:error_msg] = e.to_s
    puts e.backtrace
  end
  sleep 1
  #$all_results[:runs] << @run_results
  require 'json'
  report_file = File.join(File.dirname(__FILE__), '..','..','awetest_report', 'vnp_result.json')
  File.write(report_file, @run_results.to_json)
end

And(/^I launch "([^"]*)" and setup$/) do |app|
  @app = app
  $driver.driver.manage.timeouts.implicit_wait=0
  $driver.set_context $driver.available_contexts.first
  max_test_total_time = 1200 # 20 minutes
  $script_complete_by  = Time.now + max_test_total_time
  while not_timed_out? && !($driver.find('Phone') rescue false) || !($driver.find('Play Store') rescue false)
    $driver.back
    in_netflix = $driver.id('com.netflix.mediaclient:id/sliding_menu') rescue false
     if  in_netflix
    $driver.press_keycode 3
    end
  end
  $driver.wait {$driver.find(app).click}
  while not_timed_out? && !($driver.find('Phone') rescue false) || !($driver.find('Play Store') rescue false)
    $driver.back
    in_netflix = $driver.id('com.netflix.mediaclient:id/sliding_menu') rescue false
    if  in_netflix
         $driver.press_keycode 3
      end
  end
  $device_id = @params['selected_devices']['device_id']
end

def start_appium
  #device_id = @params[:selected_devices]['device_id']
end

And(/^I set network to be "([^"]*)"$/) do |connection_choice|
  start_appium

  #step "I launch Chrome"
  $driver.driver.manage.timeouts.implicit_wait=0
  network_select = "//*[text()='#{connection_choice}']/../../button[text()='Select']"

  @browser.goto '10.42.0.1:8000'
  sleep 2
  @browser.wait {@browser.button(text: 'Turn On').exist? || @browser.button(text: 'Turn Off').exist? }
  if connection_choice == 'LTE' || connection_choice == 'WiFi' || connection_choice == 'No limit' #LTE is no limit max limit that we can set if 4g with setting limit to 0, this is the only way it works
    @browser.button(text: 'Turn Off').flash if @browser.button(text: 'Turn Off').exist?
    @browser.button(text: 'Turn Off').click if @browser.button(text: 'Turn Off').exist?
  else
    @browser.button(text: 'Turn On').flash if @browser.button(text: 'Turn On').exist?
    @browser.button(text: 'Turn On').click if @browser.button(text: 'Turn On').exist?
    @browser.h3(text: 'Profiles').when_present.flash
    @browser.h3(text: 'Profiles').when_present.click
    @browser.element(xpath: network_select).when_present.focus
    @browser.element(xpath: network_select).when_present.flash
    @browser.element(xpath: network_select).when_present.click
    sleep 3
    @browser.button(text: 'Update Shaping').focus rescue nil
    @browser.button(text: 'Update Shaping').flash rescue nil
    @browser.button(text: 'Update Shaping').click rescue nil
  end
  sleep 1

  #restore app settings
  #$driver.caps[:app] = @current_app
  #$driver.caps[:appPackage] = @current_app_package
  #$driver.caps[:appActivity] = @current_app_activity

end

And(/^I launch Chrome$/) do
  @current_app = $driver.caps[:app]
  @current_app_package = $driver.caps[:appPackage]
  @current_app_activity = $driver.caps[:appActivity]
  $driver.caps[:app] = "Chrome"
  $driver.caps[:appPackage] = nil
  $driver.caps[:appActivity] = nil
  $driver.restart
  require 'watir-webdriver'
  @browser = Watir::Browser.new $driver.driver
end

And(/^I launch my app$/) do
  $driver.caps[:app] = @current_app
  $driver.caps[:appPackage] = @current_app_package
  $driver.caps[:appActivity] = @current_app_activity
  $driver.restart
end

And(/^I go back and start speedtest$/) do
  pending
end