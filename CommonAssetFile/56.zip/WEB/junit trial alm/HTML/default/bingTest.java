import org.junit.Test;
import junit.framework.TestCase;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class bingTest extends TestCase{

		//Tests Bing calculator
		@Test
		public void testBingPass(){
			
			//Create firfox driver's instance
			WebDriver driver = new FirefoxDriver();
			
			//Set implicit wait of 10 seconds
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			//Launch bing
			driver.get("http://www.bing.com");
			
			//Write 2+2 in bing textbox
			WebElement googleTextBox = driver.findElement(By.id("sb_form_q"));
			googleTextBox.sendKeys("2+2");
			
			//Click on searchButton
			WebElement searchButton = driver.findElement(By.id("sb_form_go"));
			searchButton.click();
			
			//Get result from calculator
			WebElement calculatorTextBox = driver.findElement(By.id("rcTB"));
			String result = calculatorTextBox.getText();
			
			//Verify that result of 2+2 is 4
			Assert.assertEquals(result, "4");

			driver.close();
		}

		//Tests Bing calculator
		@Test
		public void testBingFail(){
			
			//Create firfox driver's instance
			WebDriver driver = new FirefoxDriver();
			
			//Set implicit wait of 10 seconds
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			//Launch bing
			driver.get("http://www.bing.com");
			
			//Write 2+2 in bing textbox
			WebElement googleTextBox = driver.findElement(By.id("sb_form_q"));
			googleTextBox.sendKeys("2+2");
			
			//Click on searchButton
			WebElement searchButton = driver.findElement(By.id("sb_form_go"));
			searchButton.click();
			
			//Get result from calculator
			WebElement calculatorTextBox = driver.findElement(By.id("rcTB"));
			String result = calculatorTextBox.getText();
			
			//Verify that result of 2+2 is 6
			Assert.assertEquals(result, "6");

			driver.close();
		}

		//Tests Bing calculator
		@Test
		public void testBingElmno(){
			
			//Create firfox driver's instance
			WebDriver driver = new FirefoxDriver();
			
			//Set implicit wait of 10 seconds
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			//Launch bing
			driver.get("http://www.bing.com");
			
			//Write 2+2 in bing textbox
			WebElement googleTextBox = driver.findElement(By.id("sb_form_q"));
			googleTextBox.sendKeys("2+2");
			
			//Click on searchButton
			WebElement searchButton = driver.findElement(By.id("sb_form_goabc"));
			searchButton.click();
			
			//Get result from calculator
			WebElement calculatorTextBox = driver.findElement(By.id("rcTB"));
			String result = calculatorTextBox.getText();
			
			//Verify that result of 2+2 is 4
			Assert.assertEquals(result, "4");

			driver.close();
		}

}