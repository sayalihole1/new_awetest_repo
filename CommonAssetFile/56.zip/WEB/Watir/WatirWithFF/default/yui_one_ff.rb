  require 'rubygems'
  require 'watir-webdriver'

  def open_example(b, target)
    b.link(:text, target).when_present.click
    sleep(1)
    b.text.include?(target)
    b.link(:text, 'Code Samples').when_present.click
    sleep(2)
  end

  b = Watir::Browser.new(:firefox)
  #b = Watir::Browser.new
  p b.name
  b.goto('http://new.davglass.com/examples/')

  # examples
  b.link(:text, 'YUI: Examples').when_present.click
  tabs_div = b.div(:id, 'tabs')

  tabs_div.link(:text, 'Tab One Label').when_present.click
  tabs_div.text =~ /Tab One Label/
  tabs_div.text !=~ /Tab Two Label/
  tabs_div.text !=~ /Tab Three Label/

  tabs_div.link(:text, 'Tab Two Label').when_present.click
  tabs_div.text =~ /Tab Two Label/
  tabs_div.text !=~ /Tab One Label/
  tabs_div.text !=~ /Tab Three Label/

  tabs_div.link(:text, 'Tab Three Label').when_present.click
  tabs_div.text =~ /Tab Three Label/
  tabs_div.text !=~ /Tab One Label/
  tabs_div.text !=~ /Tab Two Label/

  b.link(:text, 'Code Samples').when_present.click

  [
    'YUI: 3-way Resizable Panel with iFrame inside',
    'YUI: Button: Menu Button in scrolled container',
    'YUI: Context Menu on a Textarea',
    'YUI: DragDrop DataTable',
    'YUI: Dialog Alert Widget',
    'YUI: Table with DragDrop Columns'
  ].each do |target|
    open_example(b, target)
  end

  b.close
