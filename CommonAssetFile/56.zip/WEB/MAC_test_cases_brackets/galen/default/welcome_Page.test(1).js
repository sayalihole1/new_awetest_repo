
load("tc_assets/tests/init.js");
load("tc_assets/tests/WelcomePage.js");

grouped(["homepage", "loginpage","testpage"], function () {
	testOnAllDevices("Welcome page", "/", function (driver, device) {
	    new WelcomePage(driver).waitForIt();
	    checkLayout(driver, "specs/welcomePage.spec", device.tags);
	});
});


grouped(["homepage", "temp"], function () {
	testOnDevice(devices.desktop, "Menu Highlight", "/", function (driver, device) {
	    var welcomePage = new WelcomePage(driver).waitForIt();
	    logged("Checking color for menu item", function () {
		checkLayout(driver, "specs/menuHighlight.spec", ["usual"]);
	    })

	    logged("Checking color for highlighted menu item", function () {
		welcomePage.hoverFirstMenuItem();
		checkLayout(driver, "specs/menuHighlight.spec", ["hovered"]);
	    });
	});
});
