require 'active_support/core_ext/class/attribute_accessors'

module Shamisen
  module WatirWebDriver
    class Wrapper
      cattr_accessor :watir_browser_class
      attr_accessor :browser, :runner, :jsonContent, :script_file

      def initialize(*args)
        browser, options = *args
        options ||= {}

        browser_args = case browser
                         when :firefox, :chrome, :safari, :ie ; [ browser, options ]
                         else                   ; []
                       end
        puts browser
        if RUBY_PLATFORM && RUBY_PLATFORM == "java" && browser == :chrome
           require 'watir-webdriver'
            #mac
            puts "in gc1_________"
            shamisen_dir = File.expand_path(File.join(File.dirname(__FILE__),"..","..",".."))
            puts shamisen_dir
            selenium_server_path = "#{shamisen_dir}/bin/selenium-server-standalone.jar"
            output = '> /dev/null 2>&1'
            sleep Random.rand(100)/100.0
            port = get_open_port
            $browser = IO.popen("java -jar #{selenium_server_path} -role hub -port #{port} #{output} \n")
            $browser_client = IO.popen("java -jar #{selenium_server_path} -role webdriver  -hub http://localhost:#{port}/grid/register -port #{get_open_port} -browser browserName=chrome,version=ANY,maxInstances=1,platform=MAC #{output} \n")
            client         = ::Selenium::WebDriver::Remote::Http::Default.new
            client.timeout = 300 # seconds – default is 60
            caps = ::Selenium::WebDriver::Remote::Capabilities.chrome("chromeOptions" => {"args" => [ "--disable-web-security --ignore-certificate-errors --disable-translate --disable-popup-blocking"  ]})
            max_sleep_time = 20
            sleep_time = 0
            begin
              puts "in gc2_________"
              sleep 1
              self.browser = ::Watir::Browser.orig_new :remote,:http_client => client, url: "http://localhost:#{port}/wd/hub", desired_capabilities: caps
            rescue => e
              sleep_time +=1
              retry if sleep_time < max_sleep_time
              raise("Error launching chrome\n #{e.to_s}")
            end
            return
        end

        self.browser = self.class.watir_browser_class.orig_new(*browser_args)
      end

      def get_open_port
        server = TCPServer.new('127.0.0.1', 0)
        port = server.addr[1]
        server.close
        port
      end

      def get_caller(lnbr=nil, exception=nil)
        script_name ||= File.basename(script_file)
          caller_object = exception ? exception.backtrace : Kernel.caller
          call_frame    = caller_object.detect do |frame|
            # frame.match(/#{script_name}/) or (library && frame.match(/#{lib_name}/))
            frame.match(/#{script_name}/)
          end
          unless call_frame.nil?
            call_frame.gsub!(/^C:/, '')
            file, line, method = call_frame.split(":")
            [File.basename(file), line, method].join(":")
          else
            'unknown'
          end
      end

      def method_missing(method_name, *args, &block)
        caller_info = get_caller
        caller_line_number = caller.first.split(':').last
		call_number = caller.to_a
		call_number = call_number.first
		call_number = call_number.split(':')[2]
		response = self.browser.send(method_name, *args, &block)
        
		#read code lines form the file
		script_line = file_reader1
        script_run = script_line[call_number.to_i-1]
		
        #self.runner.pass_to_log "#{method_name}(#{args.inspect})", caller_line_number
        jsonContent["Logs"] << ["#{script_run}", caller_info, "PASSED", Time.now, caller_line_number]
        # self.runner.pass_to_log "#{script_run}", caller_line_number

        response
      rescue Exception => e
        caller_info = get_caller(nil, e)
        jsonContent["Logs"] << [e.message, caller_info, "FAILED", Time.now, caller_line_number]
        # self.runner.fail_to_log e, caller_line_number
      end

      def file_reader1
        script_line = Array.new
        script_line = IO.readlines(self.runner.script_file)
        return script_line
      end
    end
  end
end
