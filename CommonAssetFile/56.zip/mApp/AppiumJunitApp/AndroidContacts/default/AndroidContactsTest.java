
import org.junit.Test;
import junit.framework.TestCase;
import io.appium.java_client.AppiumDriver;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.net.URL;
import java.util.List;

public class AndroidContactsTest  extends TestCase {
  private AppiumDriver driver;

    @Before
    public void setUp() throws Exception {
        // set up appium
		
    
    }

    @After
    public void tearDown() throws Exception {
        driver.quit();
    }

    @Test
  public void testAddContact(){
    		 driver = getAppiumDriver();
        WebElement el = driver.findElement(By.name("Add Contact"));
        el.click();
        List<WebElement> textFieldsList = driver.findElementsByClassName("android.widget.EditText");
        textFieldsList.get(0).sendKeys("Some Name");
        textFieldsList.get(1).sendKeys("Some@example.com");
        driver.swipe(100, 500, 100, 100, 2);
        driver.findElementByName("Save").click();
    }

  
      @Test
  public void testAddContactSample(){
    		 driver = getAppiumDriver();
        WebElement el = driver.findElement(By.name("Add Contact"));
        el.click();
        List<WebElement> textFieldsList = driver.findElementsByClassName("android.widget.EditText");
        textFieldsList.get(0).sendKeys("Some Name");
        textFieldsList.get(1).sendKeys("Some@example.com");
       
    }
}