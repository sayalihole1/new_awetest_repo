module AwetestDslAllDefaults
  def run
    passed_to_log("Hello")
    passed_to_log("Hello")
    passed_to_log("Hello")
    passed_to_log("Hello")
    passed_to_log("Hello")
    passed_to_log("Hello")
    passed_to_log("Hello")
    passed_to_log("Hello")
    
  end
end